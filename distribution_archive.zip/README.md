# Median housing value prediction

The housing data can be downloaded from https://github.com/ageron/handson-ml/blob/master/datasets/housing/housing.csv. The script has codes to download the data. We have modelled the median house value on given housing data.

The following techniques have been used:

 - Linear regression
 - Decision Tree
 - Random Forest

## Steps performed
 - We prepare and clean the data. We check and impute for missing values.
 - Features are generated and the variables are checked for correlation.
 - Multiple sampling techinuqies are evaluated. The data set is split into train and test.
 - All the above said modelling techniques are tried and evaluated. The final metric used to evaluate is mean squared error.

 ## Update the HOUSING_PATH with the location of dataset on local machine.

- To create and activate the python environment.

   ```$conda env create -f mle-dev.yml```

   ```$conda active mle-dev.yml```

## To excute the script

   ```python nonstandardcode.py```


- Install package mle_training:  ```pip install dist/mle_training-0.1.0-py3-none-any.whl```
- Run main.py python script:  ```cd scripts```  ```python3 main.py ```
- Run basic tests:  ```cd ../tests```  ```python3 -m pytest tests.py```

